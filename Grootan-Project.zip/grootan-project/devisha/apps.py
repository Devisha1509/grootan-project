from django.apps import AppConfig


class DevishaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'devisha'
