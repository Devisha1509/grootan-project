from django.contrib import admin
from .models import Devi


admin.site.register(Devi)
